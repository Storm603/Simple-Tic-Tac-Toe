﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TicTacToe
{
    public class InsertCoordinates
    {
        public Dictionary<string, int[]> Coordinates = new Dictionary<string, int[]>()
        {
            {"Up Left", new[] {1, 1}},
            {"Up Mid", new[] {1, 3}},
            {"Up Right", new[] {1, 5}},
            {"Mid Left", new[] {3, 1}},
            {"Mid Mid", new[] {3, 3}},
            {"Mid Right", new[] {3, 5}},
            {"Down Left", new[] {5, 1}},
            {"Down Mid", new[] {5, 3}},
            {"Down Right", new[] {5, 5}}
        };
    }
}
