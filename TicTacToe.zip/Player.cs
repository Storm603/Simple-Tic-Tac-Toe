﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TicTacToe
{
    public class Player
    {
        public Player(char playerSymbol)
        {
            PlayerSymbol = playerSymbol;
        }
        public char PlayerSymbol { get; private set; }

        public char DrawSymbol()
        {
            return PlayerSymbol;
        }
    }
}
