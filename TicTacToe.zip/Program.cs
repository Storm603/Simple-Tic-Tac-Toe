﻿using System;

namespace TicTacToe
{
    class Program
    {
        static void Main(string[] args)
        {
            Start start = new Start();
            start.Run();
        }
    }
}
