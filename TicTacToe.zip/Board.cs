﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TicTacToe
{
    public class Board
    {
        public Board()
        {
            Field = new string[6, 6];
        }
        public string[,] Field { get; private set; }

        public void DisplayBoard()
        {
            for (int i = 0; i <= Field.GetLength(0); i++)
            {
                for (int j = 0; j <= Field.GetLength(1); j++)
                {
                    if (i % 2 == 0 || j % 2 == 0)
                    {
                        if ((i == 2 && j == 2) || (i == 4 && j == 2) || (j == 4 && i == 2) || (j == 4 && i == 4))
                        {
                            Console.Write(" + ");
                        }
                        else if (i > 0 && i < Field.GetLength(0) && j % 2 == 0)
                        {
                            Console.Write(" | ");
                        }
                        else
                        {
                            Console.Write(" - ");
                        }
                    }
                    else
                    {
                        if (Field[i, j] == null)
                        {
                            Console.Write("   ");
                        }
                        else
                        {
                            Console.Write($" {Field[i, j]} ");
                        }
                    }
                }
                Console.WriteLine();
            }
        }

        public bool PlayerDraw(string symbol, int[] input)
        {
            int coordinateOne = input[0];
            int coordinateTwo = input[1];

            if (Field[coordinateOne, coordinateTwo] == null)
            {
                Field[coordinateOne, coordinateTwo] = $"{symbol} ";
                return true;
            }

            Console.WriteLine("You cannot place a symbol there!");
            return false;
        }

        public string CheckIfWinner()
        {
            string winner = String.Empty;

            int flag = 0;

            if (Field[1, 1] == Field[1, 3] && Field[1, 3] == Field[1, 5])
            {
                return Field[1, 1];
            }
            if (Field[3, 1] == Field[3, 3] && Field[3, 3] == Field[3, 5])
            {
                return Field[3, 1];

            }
            if (Field[5, 1] == Field[5, 3] && Field[5, 3] == Field[5, 5])
            {
                return Field[5, 1];

            }
            if (Field[1, 1] == Field[3, 1] && Field[3, 1] == Field[3, 5])
            {
                return Field[1, 1];

            }
            if (Field[1, 3] == Field[3, 3] && Field[3, 3] == Field[5, 3])
            {
                return Field[1, 3];

            }
            if (Field[1, 5] == Field[3, 5] && Field[3, 5] == Field[5, 5])
            {
                return Field[1, 5];

            }
            if (Field[1, 1] == Field[3, 3] && Field[3, 3] == Field[5, 5])
            {
                return Field[1, 1];

            }
            if (Field[1, 5] == Field[3, 3] && Field[3, 3] == Field[5, 1])
            {
                return Field[1, 5];

            }

            return "no";
        }

        //public void DisplayWinner()
        //{
        //    int p1Count = 0;
        //    int p2Count = 0;

        //    foreach (string s in Field)
        //    {
        //        if (s == " X ")
        //        {
        //            p1Count++;
        //        }
        //        else if (s == " O ")
        //        {
        //            p2Count++;
        //        }
        //    }

        //    if (p1Count == p2Count)
        //    {
        //        Console.WriteLine("Player 2 is the winner! Congratulations!");
        //    }
        //    else
        //    {
        //        Console.WriteLine("Player 1 is the winner! Congratulations!");
        //    }
        //}
    }
}
