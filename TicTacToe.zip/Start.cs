﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Text;

namespace TicTacToe
{
    class Start
    {
        public Start()
        {
            playerOne = new Player('O');
            playerTwo = new Player('X');
            coordinates = new InsertCoordinates();
        }

        private Player playerOne;
        private Player playerTwo;
        private Board board;
        private InsertCoordinates coordinates;
        public void Run()
        {
            
            while (true)
            {
                Console.WriteLine("Are you ready to play? Y/N");
                Console.WriteLine();

                string pressedKey = Console.ReadKey().Key.ToString();

                if (pressedKey == "Y")
                {
                    Console.WriteLine();

                    Console.WriteLine("Type \"Help\" if you need position input commands.");

                    board = new Board();

                    int index = 0;
                    string winner = String.Empty;
                    board.DisplayBoard();
                    bool action = false;

                    while (true)
                    {

                        if (index % 2 == 0)
                        {
                            Console.WriteLine("Player 1 turn");
                        }
                        else
                        {
                            Console.WriteLine("Player 2 turn");
                        }

                        string input = Console.ReadLine();

                        if (input == "Help")
                        {
                            int indexer = 0;
                            Console.WriteLine("Input commands are:");
                            foreach (KeyValuePair<string, int[]> pair in coordinates.Coordinates)
                            {
                                if (indexer % 3 == 0)
                                {
                                    Console.WriteLine();
                                }
                                Console.Write(pair.Key + ", ");
                                indexer++;
                            }
                            Console.WriteLine();
                            Console.WriteLine();

                            continue;
                        }
                        if (!coordinates.Coordinates.ContainsKey(input))
                        {
                            Console.WriteLine("Wrong input, please retype your action!");
                            Console.WriteLine();
                            continue;
                        }


                        if (index % 2 == 0)
                        {
                            action = board.PlayerDraw(playerOne.DrawSymbol().ToString(), coordinates.Coordinates[input]);
                        }
                        else
                        {
                            action = board.PlayerDraw(playerTwo.DrawSymbol().ToString(), coordinates.Coordinates[input]);
                        }
                        board.DisplayBoard();

                        if (!action)
                        {
                            continue;
                        }

                        if (index >= 2)
                        {
                            winner = board.CheckIfWinner();
                        }

                        if (winner == "O ")
                        {
                            Console.WriteLine("Winner is player 1");
                            break;
                        }
                        else if (winner == "X ")
                        {
                            Console.WriteLine("Winner is player 2");
                            break;
                        }

                        index++;
                    }

                    //if (flag)
                    //{
                    //    break;
                    //}
                }
                else if (pressedKey == "N")
                {
                    Environment.Exit(0);

                }

            }
        }
    }
}
